//表示依赖了全局中的Vue,像JQuery一样先定义一个作用域;分号是省略分号开头(括号时加一个分号
;(function(Vue){
	//这里的this是window
	const todos = [{
			id:1,
			title:'吃饭',
			completed:false
		},{
			id:2,
			title:'睡觉',
			completed:false
		},{
			id:3,
			title:'看云红艳老师的网课',
			completed:true
		}]

	//怎样做到Vue实例直接.data中的属性和methods中的方法
	/*
	function Vue(option){
		var {data,methods} = option//解构赋值
		for(var key in data){
			this[key] = data[key]
		} //data中的属性都成了Vue实例的实例属性
        for(var key in methods){
        	this[key] = methods[key]
        }//methods中的方法都成了Vue实例的实例方法
	}
	*/
    //为什么事件函数中的this是Vue实例,
    //因为事件触发的时候Vue实例调用事件函数(经过上面的处理已经变成他自己的实例函数)


    //操作DOM-->封装自定义指令
    //注册一个 v-focus 指令(起名时不用写v)
    Vue.directive('focus',{
        //当该元素被插入到DOM中时,执行
        inserted(elem){
            //原生DOM方式获取焦点,elem是注册v-focus的元素
            elem.focus()
        }
    })
    var app = new Vue({
    	el:'.todoapp',//挂载元素
    	data:{
    		todos,//引用new()外部的变量,todos:todos,可简写成todos,
    		//不能这么做,这里的this是window,因为是window调用的构造函数
    		//left:this.todos.filter(function(item){return !item.completed}).length
    		currentEdit:null,//看列表那里4个事件1个class
    		filter:'all',
            filtTodos:todos
    	},   
    	//计算属性,先作为方法,缓存执行结果在同名的属性中做Vue实例的实例属性,而方法不做实例方法
    	//如果方法依赖的data属性变,则重新执行并缓存,若视图改变而方法依赖的data属性没变,不重新执行
    	computed:{
            left(){
            	return this.todos.filter(item => !item.completed).length
            },

            // filtTodos(){
            // 	switch (this.filter) {
            // 		case 'all':
            // 		    return this.todos
            // 			break
            // 		case 'active':
            // 		    return this.todos.filter(item => !item.completed)
            // 			break
            // 		case 'completed':
            // 		    return this.todos.filter(item => item.completed)
            // 		    break
            // 	}
            // },

            autoCheck(){
                return this.todos.every(item => item.completed)
            }
    	},
    	methods:{
    		add(event){//es6对象的成员函数,add=function(){}可简写成add(){}
    		    //event事件对象,target事目标对象(input),input.value,trim()去首尾空格
    			var input = event.target.value.trim()
    			if(!input.length){
    				return
    			}
    			this.todos.push({
				    id:this.todos.length+1,
                    title:input,
                    completed:false
				})
				event.target.value = ''
    		},

    		toggleAll(event){
    			var check = event.target.checked
    			this.todos.forEach(item => item.completed = check)
    			console.log(this.left)
    		},
            //@click="destroy(index,$event)"
            //如果注册事件要传参数,而且需要事件对象,就再传一个$event(必须这么写)这边才能拿到event
            destroy(index){
                this.todos.splice(index,1)
            },

            clearCompleted(){
            	//filter过滤器,目标是 返回true的数组元素
                this.todos = this.todos.filter(function(item,index){
                	return !item.completed
                })
            },
            //模板中也可以执行方法,但是每次视图改变,不管方法依赖的data数据变没变,都要重新调用方法,已被计算属性代替
            getLeft(){
            	return this.todos.filter(function(item){
            		return !item.completed
            	}).length
            },

            saveEdit(index,event){
            	var text = event.target.value.trim()
            	if(!text.length){
            		return this.todos.splice(index,1)
            	}
            	this.todos[index].title  = text
            	this.currentEdit=null

            }
    	}  
    })

    window.onhashchange = function(){
    	var hash = window.location.hash.substr(2) || 'all'
        // app.filter = hash
        switch (hash) {
            case 'all':
                app.filtTodos = app.todos
                break
            case 'active':
                app.filtTodos = app.todos.filter(item => !item.completed)
                break
            case 'completed':
                app.filtTodos = app.todos.filter(item => item.completed)
                break  
            default:
                break
         }
    }
})(Vue)

//普通匿名函数中的this是window
//箭头匿名函数中的this取决于这个函数执行时的外部环境的this

//Vue是典型的MVVM框架(Model-View-ViewModel-Model),数据驱动视图

//点击all\active\completed显示不同状态的todos:
/*条件列表渲染:1.v-for="" v=if="" 2.计算属性
for if能实现简单的条件列表渲染,但很难做这么动态的事
计算属性filtTodos: v-for="filtTodos" 让for循环的数组是计算属性,动态更新
filtTodos定义函数:不同状态下返回不同筛选的todos
状态由app.filter记录
因为那是三个a标签,点击改变hash,所以注册hashchange事件,获取hash赋给app.filter改变状态
这样,点击按钮,改变状态,计算属性依赖状态,也随之执行并改变,视图随之改变渲染*/

/*全选联动
当每个任务都选中时,全选按钮也应该选中
按以前的思路,每个li注册点击事件:每个todo点击时都要根据todos中全部completed与否改变全选状态,全选按钮根据全选状态改变
但是这没有把Vue的响应式发挥到极致,
直接给全选按钮绑定个计算属性(单向绑定checked就行),该属性定义时返回一个bool全选状态
*/