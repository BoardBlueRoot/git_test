<template>
	<div class="app">
		<h1>app</h1>
		<router-link to="/bar" exact tag="li"><a href="">go to bar</a></router-link>
		<router-link to="/foo" exact tag="li"><a href="">go to foo</a></router-link>
		<router-view>路由出口</router-view>
	</div>
</template>

<script>
    import Bar from './components/Bar.vue'
    import Foo from './components/Foo.vue'

	export default {

        components:{
            Bar,
        	Foo
        }
	}
</script>

<style>
	
</style>