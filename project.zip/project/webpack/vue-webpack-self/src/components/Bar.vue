<template>
	<div class="bar">
		<h1>Bar</h1>
	</div>
</template>