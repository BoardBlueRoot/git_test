import VueRouter from 'vue-router'
import Bar from './components/Bar.vue'
import Foo from './components/Foo.vue'

export default new VueRouter({
	routes:[
        {
        	path:'/bar',
        	component:Bar
        },
        {
        	path:'/foo',
        	component:Foo
        }
	]
})