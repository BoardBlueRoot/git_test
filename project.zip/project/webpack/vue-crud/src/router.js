import VueRouter from 'vue-router'
import Crud from './components/Crud.vue'
import Dash from './components/Dash.vue'
import New from './components/New.vue'
import Edit from './components/Edit.vue'

export default new VueRouter({
    linkActiveClass:'active',
    routes:[
        {
            path:'/',
	    component:Dash
        },
        {
            path:'/crud',
            component:Crud
        },
        {
            path:'/crud/new',
            component:New
        },
        {
            path:'/crud/edit',
            component:Edit
        }
    ]
})