<template>
	<div class="app">
		<Nav></Nav>
        <div class="container-fluid">
            <div class="row">
                <Aside></Aside>
            </div>
        </div>
        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
    		<router-view></router-view>        
        </main>

	</div>
</template>

<script>
    import Nav from './components/Nav.vue'
    import Aside from './components/Aside.vue'

	export default {
        //Crud,Dash等,没有在上面模板中出现,就不用加进来
        components:{
        	Nav,
        	Aside
        }
	}
</script>

<style>

</style>
//单文件组件
//根组件文件:
把整个静态页面放到template里,大的包裹性的节点留在template做子组件的父节点,局部的可抽取的节点抽取出来做子组件的template,留出路由出口,路由组件按路由在这里显示
引入子组件,在导出组件对象中挂载子组件(路由组件在template中没有出现,不引)
//子组件文件:
template中也可以抽取子组件
导出组件对象,data是函数返回一个对象,methods注册事件处理交互(增删改查crud),created钩子负责请求第一次加载时的展示数据
//嵌套路由:
不嵌套,项目中出现的router-view都按唯一的路由表显示,
嵌套:new VueRouter({
    routes:[
        {
            path:,
            component:
        },
        {
            path:,
            component:,
            children:[
                {
                    path:,
                    component:
                },
                {
                    path:,
                    component:
                }
            ]
        }
    ]
}),路由组件中也可以用router-view进行子路由操作

