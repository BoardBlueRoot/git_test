<template>
	<div id="edit">
		<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h1 class="h2">Edit Student</h1>
			<div class="btn-toolbar mb-2 mb-md-0">
				<div class="btn-group mr-2">
					<button type="button" class="btn btn-sm btn-outline-secondary">Share</button>
					<button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
				</div>
				<button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
					<span data-feather="calendar"></span>
					This week
				</button>
			</div>
		</div>

		<form method="post" @submit.prevent="edit">

			<div class="form-group">
				<label for="exampleInputEmail1">姓名</label>
				<input type="text" class="form-control" name="name" placeholder="name" v-model="formData.name">
			</div>

			<div class="form-group">
				<label for="exampleInputPassword1">年龄</label>
				<input type="text" class="form-control" name="age" placeholder="age" v-model="formData.age">
			</div>

			<button type="submit" class="btn btn-success">Submit</button>

		</form>
	</div>

</template>

<script>
	import axios from 'axios'

	export default {
		data(){
			return{
				formData:{
					id:'',
					name:'',
					age:''
				}
			}
		},
		methods:{
			edit(){
                const {id} = this.formData//对象解构赋值
				axios.patch('http://localhost:3000/students/'+id,this.formData).then(res => this.$router.back())
				//或$router.go(-1)或$router.push('/crud')
			}
		},
		created(){
			//$route路由参数对象,可以拿到路由参数,$route路由实例对象,可以做路由操作
			const {id} = this.$route.query//对象解构赋值
			axios.get('http://localhost:3000/students/'+id).then(res => this.formData = res.data)
		}
	}
</script>

<style>
</style>