<template>
	<div id="crud">
		<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">   
			<h1 class="h2">Student Information</h1>
			<div class="btn-toolbar mb-2 mb-md-0">
				<div class="btn-group mr-2">
					<button type="button" class="btn btn-sm btn-outline-secondary">Share</button>
					<button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
				</div>
				<button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
					<span data-feather="calendar"></span>
					This week
				</button>
			</div>
		</div>
		<a href="#/crud/new" class="btn btn-success" id="add-stu">添加学生</a>
		<table class="table table-striped table-sm">
			<thead>
				<tr>
					<th>ID</th>
					<th>姓名</th>
					<th>年龄</th>
					<th>操作</th>
			
				</tr>
			</thead>
			<tbody>
				<tr v-for="item in list">
					<td>{{item.id}}</td>
					<td>{{item.name}}</td>
					<td>{{item.age}}</td>
					<td>
						<a class="btn btn-danger" @click="deleteById(item.id)">删除</a>
						<!-- :href动态绑定属性后,""内是个变量 -->
						<a class="btn btn-success" :href="`#/crud/edit?id=${item.id}`">编辑</a>
					</td>
				</tr>
			</tbody>
		</table>
	</div>      
</template>

<script>
	import axios from 'axios'

	export default {
		data(){
			return{
				list:[]
			}
		},
		methods:{
			loadList(){
				axios.get('http://localhost:3000/students').then(res => this.list = res.data)
			},
			deleteById(id){
				if(!window.confirm('确定要删除吗?'))return
				axios.delete('http://localhost:3000/students/'+id).then(res => this.loadList())
			}
		},
		created(){
			this.loadList()
		}
	}
</script>

<style>
td a{
	margin-right: 20px;
}
</style>