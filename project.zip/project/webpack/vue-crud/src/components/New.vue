<template>
	<div id="new">
		<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h1 class="h2">Add Student</h1>
			<div class="btn-toolbar mb-2 mb-md-0">
				<div class="btn-group mr-2">
					<button type="button" class="btn btn-sm btn-outline-secondary">Share</button>
					<button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
				</div>
				<button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
					<span data-feather="calendar"></span>
					This week
				</button>
			</div>
		</div>

		<form method="post" @submit.prevent="add">

			<div class="form-group">
				<label for="exampleInputEmail1">姓名</label>
				<input type="text" class="form-control" name="name" placeholder="name" v-model="formData.name">
			</div>

			<div class="form-group">
				<label for="exampleInputPassword1">年龄</label>
				<input type="text" class="form-control" name="age" placeholder="age" v-model="formData.age">
			</div>

			<button type="submit" class="btn btn-success">Submit</button>

		</form>
	</div>

</template>

<script>
	export default {
		data(){
			return{
				formData:{
					name:'',
					age:''
				}
			}
		},
		methods:{
			add(){
				axios.post('http://localhost:3000/students',this.formData).then(res => this.$router.back())
				//或$router.go(-1)或$router.push('/crud')
			}
		}
	}
</script>

<style>
</style>