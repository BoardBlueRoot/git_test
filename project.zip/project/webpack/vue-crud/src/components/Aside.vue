<template>
	<nav class="col-md-2 d-none d-md-block bg-light sidebar">
      <div class="sidebar-sticky">
        <ul class="nav flex-column">

          <li class="nav-item">
   	          <router-link class="nav-link" to="/" exact tag="a">Dash</router-link>
          </li>

          <li class="nav-item">
   	          <router-link class="nav-link" to="/crud" tag="a">CRUD</router-link>
          </li> 

          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="home"></span>
              Dashboard <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
              <span data-feather="file"></span>
              CRUD
            </a>
          </li>
          
        </ul>

        
      </div>
    </nav>
</template>

<script>
	export default {
	    data(){
	        return{}
	    }
	}
</script>

<style>
</style>