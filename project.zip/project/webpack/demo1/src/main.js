import a from './a.js'
a()

import './main.css'

const arr = [1,2,3]
arr.forEach(item => console.log(item))