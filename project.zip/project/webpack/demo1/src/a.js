module.exports = function(){
	console.log('aaa');
}