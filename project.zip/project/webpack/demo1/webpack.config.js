var path = require('path')
const htmlWebpackPlugin = require('html-webpack-plugin')

module.exports={
	entry:'./src/main.js',
	output:{
		path:path.join(__dirname,'./dist/'),
		filename:'bundle.js'
	},
	module:{
	    rules:[{test:/\.css$/,use:['style-loader','css-loader']},
	           {test:/\.(png|jpg|gif|svg)$/,use:'file-loader'}]
	           // {test:/\.js$/,exclude:/(node_modules|bower_components)/,use:{loader:'babel-loader',options:{presets:['env']}}}]
    },
    mode:'development',
    // mode:'production',
    //把index.html也打包到bundle.js所在路径,并自动引入<script src="bundle.js",且bundle改名,index引入也跟着改
    plugins:[new htmlWebpackPlugin({template:'./index.html'})],
    devServer:{contentBase:'./dist/'}
}

