var path = require('path')
const htmlWebpackPlugin = require('html-webpack-plugin')
const VueLoaderPlugin = require('vue-loader/lib/plugin')
const webpack = require('webpack')

module.exports={
	entry:'./src/main.js',
	output:{
		path:path.join(__dirname,'./dist/'),
		filename:'bundle.js'
	},
	module:{
        rules:[
            {
            	test:/\.css$/,
            	use:['style-loader','css-loader']
            },
            {
        	    test:/\.(jpg|png|gif|svg)$/,
        	    use:'file-loader'
            },
            {
            	test:/\.vue$/,
            	use:'vue-loader'
            },
            {
            	test:/\.less$/,
            	use:[
                    'style-loader',
                    'css-loader',
                    'less-loader'
            	]
            }
	    ]
	},
	plugins:[
        new htmlWebpackPlugin({template:'./index.html'}),
        new VueLoaderPlugin(),
        new webpack.NamedModulesPlugin(),
        new webpack.HotModuleReplacementPlugin()
	],
	devServer:{
		contentBase:'./',
		hot:true
	},
	externals:{
        jquery:'jQuery',
        vue:'Vue'
	},
	mode:'production'
}