<template>
    <div id="app">
    	<h2>{{message}}</h2>
    	<Foo></Foo>
    </div>
</template>

<script>
	import Foo from './components/Foo.vue'
	//组件有绑定数据,就要导出一个默认对象,这个对象就是这个组件,不绑定数据,可以不导出
	export default {
		data(){
			return {
				message:'hello,vue'
			}
		},
		components:{
			Foo
		}
	}
</script>

<style>
    #app{
    	display: inline-block;
    	width: 400;
    	height:300;
    	background-color: pink;
    }
	h2{
		color:red;
	}
</style>
