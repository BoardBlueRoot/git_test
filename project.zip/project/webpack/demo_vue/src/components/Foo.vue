<template>
	<div class="foo">
	    <h2>{{message}}</h2>
		<div class="a">
			<h3>aaa</h3>
			<h4>bbb</h4>
		</div>
	</div>
</template>

<script>
	export default {
		data(){
			return {
				message:'Foo Message'
			}
		}
	}
</script>

<!-- 子组件style加scoped则子组件样式与父组件样式冲突时,以子组件为准,不加则以父组件为准 -->
<style lang="less" scoped>
	h2{
		color:blue;
	}
    .a{
    	border: 1px solid black;
    	h3{
    		color:yellow;
    	}
    	h4{
    		color:green;
    	}
    }
</style>