import $ from 'jquery'
import Vue from 'vue'
import App from './App.vue'

//这里选择器能选到的只有index.html本身就有的元素,index中的组件,在这里选择不到
$('#head').css({
	width:200,
	height:100,
	backgroundColor:'green'
})

new Vue({
    el:'#app',
    template:'<App />',
    components:{
    	App
    }
})

console.log('hhhhh')