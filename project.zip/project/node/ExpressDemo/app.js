var express = require('express')
var server = express();

server.get('/',function(req,res){
	res.send('<h1>index<br>Hello,Express!</h1>')
})
server.get('/login',function(req,res){
	res.send('<h1>login<br>Hello,Express!</h1>');
})

server.use('/static/',express.static('./static/'));

server.use(express.static('./public/'));

server.listen(329,function(){
	console.log('服务器启动终了');
})