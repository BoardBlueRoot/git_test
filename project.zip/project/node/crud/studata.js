/*
 * 学生数据处理模块,封装异步函数
 * 异步编程:Node的精华所在
 */

var fs = require('fs')
var dbpath = './db.json'
 
/*
 * 增
 */
exports.stuAdd=function(student,callback){
	fs.readFile(dbpath,'utf-8',function(err,data){
		if(err){
			callback(err)
		}
		var stuarr = JSON.parse(data).students
		student.id = stuarr[stuarr.length-1].id+1
		stuarr.push(student)
		var str = JSON.stringify({students:stuarr})
		fs.writeFile(dbpath,str,function(err){
			if(err){
				callback(err)
			} 
			callback(null)
		})
	})
}


/*
 * 删
 */
exports.stuDel = function(id,callback){
	fs.readFile(dbpath,'utf-8',function(err,data){
		if(err){
			callback(err)
		}
		var stuArr = JSON.parse(data).students
		var index = stuArr.findIndex(function(elem){
			return elem.id == id
		})
		stuArr.splice(index,1)
		fs.writeFile(dbpath,JSON.stringify({students:stuArr}),function(err){
			if(err){
				callback(err)
			}
			callback(null)
		})
	})
}

/*
 * 改
 */
exports.stuUpd = function(student,callback){
	fs.readFile(dbpath,'utf-8',function(err,data){
		if(err){
			callback(err)
		}
		var stuArr = JSON.parse(data).students
		var editElem = stuArr.find(function(elem){
			return elem.id == student.id
		})
		console.log(editElem)
		for(var key in student){
			editElem[key] = student[key]
		}
		var str = JSON.stringify({students:stuArr})
		fs.writeFile(dbpath,str,function(err){
			if(err){
				callback(err)
			}
			callback(null)
		})
	})
}

/*
 * 查
 * 读文件是异步操作,一个函数要想返回一个异步操作结果,只能用回调函数
 * 你接收到函数返回的异步结果想干什么,就把他写成一个回调函数,作为参数传入这个函数
 */
exports.stuQur=function(callback){
	//2参设置以utf8编码读取,读到的是string
	//或者data.toString()
	fs.readFile(dbpath,'utf-8',function(err,data){
		if(err){
			//这是异步操作的结果,直接交给回调函数bv
			处理
			return callback(err)
		}
		//parse:字符串转json,stringify:json转字符串
		return callback(null,JSON.parse(data).students)
	})
}

exports.stuQurById = function(id,callback){
	fs.readFile(dbpath,'utf-8',function(err,data){
		if(err){
			callback(err)
		}
		var stuArr = JSON.parse(data).students
		var elem = stuArr.find(function(elem){
			return elem.id == id
		})
		callback(null,elem)
	})
}
