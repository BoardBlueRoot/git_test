/*
 * 路由模块,功能:处理路由
 */

var express = require('express')
var fs = require('fs')
var Stu = require('./Studata')
var bodyParser = require('body-parser')


//创建一个路由容器
var router = express.Router()

router.use(bodyParser.urlencoded({extended:false}))
router.use(bodyParser.json())

//把路由都挂载到路由容器上
router.get('/',function(req,res){
	//StuQur函数,参数是一个函数(回调函数)
	Stu.stuQur(function(err,stuArr){
		if(err){
			return res.status(500).send('Server Error!')
		}
		res.render('index.html',{students:stuArr})
	})
})

router.get('/new',function(req,res){
	res.render('new.html')
})

router.post('/new',function(req,res){
	//console.log(req.body)
	Stu.stuAdd(req.body,function(err){
		if(err){
			return status(500).send('服务器错误,读写文件不能!')
		}
		res.redirect('/')
	})
})

router.get('/edit',function(req,res){
	Stu.stuQurById(req.query.id,function(err,student){
		if(err){
			return res.status(500).send('服务器错误,读取文件不能!')
		}
		res.render('edit.html',{
			id:req.query.id,
			name:student.name,
			gender:student.gender,
			age:student.age,
			skill:student.skill
		})
	})
})

router.post('/edit',function(req,res){
	 Stu.stuUpd(req.body,function(err){
	 	console.log(req.body)
	 	if(err){
	 		res.status(500).send('服务器错误,读写文件不能!')
	 	}
	 	res.redirect('/')
	 })
})

router.get('/delete',function(req,res){
	Stu.stuDel(req.query.id,function(err){
		if(err){
	 		res.status(500).send('服务器错误,读写文件不能!')
		}
		res.redirect('/')
	})
})
module.exports = router