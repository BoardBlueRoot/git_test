var template = require ('template-web');
var http = require ('http');
var fs = require ('fs');

var server = http.createServer ();
var wwwDir = 'D:/www';

server.on ('request',function (req,res){
	var url = req.url;
	
	fs.readFile ('./template-apache.html',function (err,data){
		if(err){
			res.setHeader('Content-Type','text/plain;charset=utf-8');
			return res.end ('读取模板文件失败');
		}
		fs.readdir(wwwDir,function (err,files){
			if(err){
				res.setHeader('Content-Type','text/plain;charset=utf-8');
				return res.end ('读取目录失败');
			}
			
			var htmlStr = template.render (data.toString(),{
				title:wwwDir+url+'的索引',
				files:files
			})
			
			res.end(htmlStr);
		})
	});
	
	
	
})

server.listen (329,function (){
	console.log('服务器启动终了:329');
})
