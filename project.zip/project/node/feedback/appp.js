var comments = [{name:'乔峰',message:'降龙十八掌'},
				{name:'段誉',message:'六脉神剑'},
				{name:'杨过',message:'黯然销魂掌'},
				{name:'小龙女',message:'玉女素心剑'}];

var express = require('express')
var bodyParser = require('body-parser')

var server = express();

//配置用于Express的模板引擎,参数一:只能渲染什么类型文件
server.engine('html',require('express-art-template'))
//server.set('views',rander函数的默认路径)//如果不set,默认从views文件夹里找被渲染的文件

//Express提供了获取get请求参数的API.query,没有提供解析post请求参数的API,要通过中间件来完成
//配置body-parser,配置之后req下会多出一个body成员属性
server.use(bodyParser.urlencoded({extended:false}))
server.use(bodyParser.json())
server.get('/',function(req,res){
	res.render('index.html',{comments:comments})
})
server.get('/post',function(req,res){
	//有了模板引擎就不用读文件了,都用渲染
	res.render('post.html')
})
server.post('/post',function(req,res){
	var comment = req.body
	comments.unshift(comment)
	res.render('index.html',{comments:comments})
})
//访问后bootstrap加载失败,原因是没有开放public文路径
server.use('/public/',express.static('./public/'))
    // res.render('404.html',{key:'哈哈哈'})

server.listen(329,function(){
	console.log('服务器启动终了');
})