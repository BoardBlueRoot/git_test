var http = require('http');
var fs = require('fs');
var url = require('url');
var template = require('art-template');
var comments = [{name:'乔峰',message:'降龙十八掌'},
				{name:'段誉',message:'六脉神剑'},
				{name:'杨过',message:'黯然销魂掌'},
				{name:'小龙女',message:'玉女素心剑'}];
http
.createServer(function(req,res){//函数自动作为server.on('request')
	var pathobj=url.parse(req.url,true); 
	var pathname=pathobj.pathname;
	if(pathname==='/'){
		fs.readFile('./views/index.html',function(err,data){
			if(err){
				return res.end('404 Not Found');
			}
			var htmlStr = template.render(data.toString(),{comments:comments});
			res.end(htmlStr);
		});
	}else if(pathname==='/post'){
		fs.readFile('./views/post.html',function(err,data){
			if(err){
				return res.end('404 Not Found');
			}else{
				res.end(data);
			}
		})
	}else if(pathname.indexOf('/public')===0){
		//如果访问公共文件,就读出来响应他,其他文件不能访问
		fs.readFile('.'+pathname,function(err,data){
			if(err){
				return res.end('404 Not Found');
			}else{
				res.end(data);
			}
		})
	}else if(pathname==='/comments'){
		var comment = pathobj.query;
		comment.dateTime = '2019-09-15 17:21';
		comments.unshift(comment);
		res.statusCode = 302;
		res.setHeader('Location','/');
		res.end();
	}else{
		//请求其他的都处理成404 
		fs.readFile('./views/404.html',function(err,data){
			if(err){
				return res.end('404 Not Found');
			}else{
				res.end(data);
			}
		});
	}
 	
})
.listen(329,function(){
	console.log('服务器启动终了');
})

