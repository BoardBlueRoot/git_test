var path = require('path')

console.log(path.basename('/a/b/c/index.html'))
//index.html

console.log(path.basename('/a/b/c/index.html', '.html'))
//index

console.log(path.dirname('/a/b/c/index.html'))
//   /a/b/c

console.log(path.extname('/a/b/c/index.html'))
//.html

console.log(path.parse('/a/b/c/index.html'))
//{root:'/',dir:'/a/b/c',base:'index.html',ext:'.html',name:'index'}

console.log(path.join('/a/b/c/','/d/e'))
//路径拼接,可以自动处理多/少/的问题

/*  __dirname  */
//与模块相关的api除了require\exports,还有
//__dirname动态获取当前模块文件所在目录的绝对路径
//__filename动态获取当前模块文件的绝对路径
console.log(__dirname)
//D:\www\node
console.log(__filename)
//D:\www\node\pathDemo.js

//相对路径:相对于执行node命令的路径,不是相对于文件
//  a\b\c\d > node app  相对于a\b\c\d\
//  a\b\c > node d\app  相对于a\b\c\
//所以说在文件操作中使用相对路径是不可靠的
//当一个模块文件被他的叔叔js文件引入了,就会出现上述问题
//所以应该用绝对路径,但是路径写死了,不鲁棒了
//所以要用__dirname动态获取绝对路径
console.log(path.join(__dirname,'./js/test.js'))
//不管是'./js'还是'/js','js',都能给你拼对了

//所以fs和path成对引入,文件操作时用path.join()拼接__dirname和文件名