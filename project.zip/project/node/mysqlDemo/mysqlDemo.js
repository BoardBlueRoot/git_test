var mysql = require('mysql')

//创建连接
var connection = mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'root',
    database:'baixiu'
})
connection.connect()

//执行
connection.query('select * from users limit 10',function(err,data){
	if(err){
		throw err
	}
	//data是个数组,data[0]是第一条数据
	console.log(data)
})

//关闭资源
connection.end()