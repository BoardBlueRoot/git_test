//1.引包
var mongoose = require('mongoose')
//2.Schema:结构,架构,设计图
var Schema = mongoose.Schema

//3.连接数据库,库可以不存在,动态创建    端口:27017可省略
mongoose.connect('mongodb://localhost/test',{useMongoClient:true})

//4.约束文档结构,文档就是一个数据项,MongoDB-库-集合-文档
var userSchema = new Schema({
	username:{
		//类型:JS中的类型
		type:String,
		//表示必须有
		required:true
	},
	password:{
		type:String,
		required:true
	}
})

//5.将文档结构发布为模型
//参一:首字母大写的单数,mongo将小写复数作为集合名
//参二: 架构 Schema
var User = mongoose.model('User',userSchema)
//增删改查均为异步操作////query//按条件query//按id query//////////////////////
//增:1.new一个架构实例 2.save()保存 (连续插入同一个,都保存,id不同)
var QiaoFeng = new User({
	username:'qiaofeng',
	password:'xlsbz'
})
QiaoFeng.save(function(err,data){
	if(err){
		console.log(err)
		console.log('保存不能!')
	}
	console.log(data)
	console.log('保存终了!')
})

//查:用模板(集合)查:模板.find()返回一个数组
//查所有
User.find(function(err,data){
	if(err){
		console.log(err)
		console.log('查询不能!')
	}
	console.log(data)
	console.log('查询终了!')
})
//条件查
User.find({username:'qiaofeng'},function(err,data){
	if(err)console.log(err)
	console.log(data)
})

//删:remove()同find()
//

//改 通过自动生成的_id找到并修改
User.findByIdAndUpdate('5d860548f2bbbe23b0e18281',{username:'AZhu'},function(err,data){
	if(err)console.log(err)
		console.log(data)
})

//find\findOne\findById\xxx\findOneAndxxx\findByIdAndxxx

//js中字符串replace方法
//str.replace('a','')
//替换全部str.replace(/a/g,'')用正则g:global