 //引包
var mongoose = require('mongoose')
//连接数据库
mongoose.connect('mongodb://localhost/test',{useMongoClient:true})

mongoose.Promise = global.Promise

var Cat = mongoose.model('Cat',{name:String,age:Number});
var tom = new Cat({name:'Tom',age:18})
tom.save(function(err){
	if(err){
		console.log(err)
	}
	console.log('successful')
})
