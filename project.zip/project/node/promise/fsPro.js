/*
多个异步操作完成的先后顺序无法确定,当希望多个异步操作按一定顺序执行,就要把一个异步操作放到另一个异步操作的回调函数里
这样多个异步操作的嵌套,代码丑,不好维护,为解决这个,ES6有Promise,他是个构造函数.
用Promise可以保证多个异步操作完全按照顺序执行
node 中 mongodb的所有api都支持promise,即直接.then就行不用创建Promise实例,JQuery封装的AJAX$.get也是.  
*/

var fs = require('fs')

//promise容器,里边装一个任务pending(即一个方法),pending的结果只有两个:resolved,rejected,且一旦有结果就不能改变结果
//pending里边定义了什么时候resolved什么时候rejected,而具体resolved\rejected了怎么做,在then()
//then的参数是两个方法,第一个是resolved方法的定义,第二个是rejected方法的定义

function fsPro (path){
	//创建一个Promise实例,只有Promise才能.then.then.then
    return new Promise(function(resolve,reject){
        fs.readFile(path,'utf-8',function(err,data){
        	if(err)reject(err)
        	resolve(data)
        })
    })
}

fsPro('./aa.txt')
.then(
	//then有两个参数,第一个是点他的Promise的resolve方法,第二个是reject方法
	function(data){
	    console.log(data)
	    return fsPro('./b.txt')
    },
    function(err){
    	//throw err直接在控制台上打印错误,并中断本次函数调用(一串then到此中断,但后面的正常执行)
        throw err
        // console.log('错了')
    }
)//如果上次失败了,返回一个Promise{<pending>}应该是个空Promise对象,默认是
.then(function(data){
	console.log(data)
	return fsPro('./c.txt')
},function(err){
	throw err
})
.then(function(data){
	console.log(data)
},function(err){
	throw err
})

// fs.readFile('./a.txt','utf-8',function(err,data){
// 	if(err)throw err
// 	console.log(data)
// })
// fs.readFile('./b.txt','utf-8',function(err,data){
// 	if(err)throw err
// 	console.log(data)
// })
// fs.readFile('./c.txt','utf-8',function(err,data){
// 	if(err)throw err
// 	console.log(data)
// })