<?php
define('DB_HOST','localhost');
define('DB_USN','root');
define('DB_PSW','root');
define('DB_NAME','baixiu');