<?php
  //封装公用函数

  require_once 'config.php';
  session_start();
  
  //检查是否登陆
  function get_user(){
  	if(empty($_SESSION['current_login_user'])){
  		header('Location: /admin/login.php');
  		exit();
  	}
  	return $_SESSION['current_login_user'];
  }

  //数据库查询多行,返回索引数组套关联数组
  function fetch($sql){
  	$conn=mysqli_connect(DB_HOST,DB_USN,DB_PSW,DB_NAME);
  	if(!$conn){
  		exit('数据库连接失败');
  	}

  	$query=mysqli_query($conn,$sql);
    if(!$query){
    	//查询失败
    	return false;
    }

    while($row=mysqli_fetch_assoc($query)){
    	$result[]=$row;
    }

    mysqli_free_result($query);
    mysqli_close($conn);

    return $result;
  }
  //查询单行,返回关联数组
  function fetch_one_row($sql){
  	$result=fetch($sql);
  	return isset($result[0]) ? $result[0] : null;
  }