<?php
  // require_once'../../config.php';
  if(empty($_GET['email'])){
    exit('缺少必要参数');
  }
  $email=$_GET['email'];

  // $conn=mysql_connect(DB_HOST,DB_USN,DB_PSW,DB_NAME);
  $conn=mysqli_connect('localhost','root','root','baixiu');
  if(!$conn){
    exit('数据库连接失败');
  }
  $res=mysqli_query($conn,"select avatar from users where email = '{$email}' limit 1;");//limit 1:找第一个
  if(!$res){
    exit('查询失败');    
  }
  $row=mysqli_fetch_assoc($res);
  echo $row['avatar'];
?>